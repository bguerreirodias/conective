<?php
	

	$nome=$_POST["name"];
	$email=$_POST["email"];
	$senha=$_POST["psw"];

	include_once'conexao.php';
	$msg="";
	$flag=true;

	if (!preg_match("/[A-Za-zá-ú]{3,30}/", $nome)) {
		$flag=false;
		$msg.="<div>Preencha o campo nome</div>";
	}
	if (!preg_match("/[a-z0-9_.-]+@[a-z0-9_.-]+\.[a-z]{2,4}+/", $email)) {
		$flag=false;
		$msg.="<div>Preencha o campo email</div>";
	}
	if (!preg_match("/[A-Za-z0-9]{8,12}/", $senha)) {
		$senha=false;
		$msg.="<div>Preencha o campo senha</div>";
	}

	$sql="select * from clientes where email = '".$email."'";
	$rs=mysqli_query($con,$sql);
	if (mysqli_num_rows($rs)>0) {
		$flag=false;
		$msg.="<div>E-mail já cadastrado!</div>";
	}

	if ($flag==true) {
		
		$sql="insert into clientes values(null,'".$nome."','".$email."','".md5($senha)."')";
		if (mysqli_query($con,$sql)) {
				$msg="Cliente cadastrado com sucesso.";
			}else{
			$msg="Erro ao cadastrar cliente.";
		}
		header("Location:login.php");
	} else{
		mysqli_close($con);
		echo $msg;
	}

?>