<div id="top">
        <div class="container">
            <div class="col-md-6 offer" data-animate="fadeInDown">
                <a href="#" class="btn btn-success btn-sm" data-animate-hover="shake">Oferta da semana</a>  <a href="#">Ganhe 50% de descontos no produtos marcados</a>
            </div>
            <div class="col-md-6" data-animate="fadeInDown">
                <ul class="menu">
                    <li><a href="login.php" >Entrar</a>
                    </li>
                    <li><a href="register.php">Registro</a>
                    </li>
                    <li><a href="#">Contato</a>
                    </li>
                </ul>
            </div>
        </div>
</div>
            
   