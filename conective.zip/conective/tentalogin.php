<?php

session_start();

include_once'conexao.php';

$email = $_POST["email"];
$senha = md5($_POST["psw"]);
?>

<script>alert('<?php echo "Email".$email ?>')</script>

<?php
$sql = "select * from clientes where email = '".$email."' and senha = '".$senha."'";
     
	 $result = mysqli_query($con,$sql); 
	 
	 if(mysqli_num_rows($result) == 1){

	 	$row=mysqli_fetch_array($result);
		// usuario esta logado
		$_SESSION["nome"] = $row["nome"];
		$_SESSION["tempo"] = time();
		
		header("location:customer-account.php");
		//header("location:adm/index.php");// redirecioanar

	 }else{
		 $msg = base64_encode("Email e/ou Senha inválido(s)");
		 header("location:login.php?msg=".$msg);// redirecionamento em php
	 }





 ?>