create database conective

create table clientes(
	cliente_id int not null AUTO_INCREMENT,
	nome varchar(50),
	email varchar(50) unique,
	senha varchar(12),
	PRIMARY KEY (cliente_id)
);

insert into clientes values ('', 'Bruno', 'bruno@bruno.com', md5('123'));