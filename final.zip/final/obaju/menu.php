<div id="top">
        <div class="container">
            <div class="col-md-6 offer" data-animate="fadeInDown">
                <a href="#" class="btn btn-success btn-sm" data-animate-hover="shake">Oferta da semana</a>  <a href="#">Ganhe 50% de descontos no produtos marcados</a>
            </div>
            <div class="col-md-6" data-animate="fadeInDown">
                <ul class="menu">
                    <li><a href="#" data-toggle="modal" data-target="#login-modal">Entrar</a>
                    </li>
                    <li><a href="register.html">Registro</a>
                    </li>
                    <li><a href="contact.html">Contato</a>
                    </li>
                </ul>
            </div>
        </div>
            
    </div>